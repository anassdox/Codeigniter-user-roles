<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();

$autoload['libraries'] = array('form_validation','session','pdf');

$autoload['drivers'] = array();

$autoload['helper'] = array('form','url','file','event');

$autoload['config'] = array();

$autoload['language'] = array('auth');

$autoload['model'] = array('user_model','form_model');