<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Root extends CI_Controller {

	public function __construct() {
		
		parent::__construct();
		$_SESSION['msg'] = '';
	}
	
	
	public function index() {
		$this->auth(); 
	}

	public function backup(){
		// Load the DB utility class
		$this->load->dbutil();

		// Backup your entire database and assign it to a variable
		$backup = $this->dbutil->backup();

		// Load the file helper and write the file to your server
		$this->load->helper('file');
		write_file('/save/db/mybackup.gz', $backup);

		// Load the download helper and send the file to your desktop
		$this->load->helper('download');
		force_download('db___'.date('Y_m_d___').'.gz', $backup);

	}
	
	public function list_user(){
	    $data['data'] = $this->form_model->get_data_query('SELECT * FROM users WHERE 1 GROUP BY id'  );
	    
	    $this->load->view('header'); 
		$this->load->view('root/listes', $data);
		$this->load->view('footer');
	}
	public function role_user($id){
	    
	    $data['user'] = $this->form_model->get_row_query('SELECT * FROM users WHERE id='.$id );
	    $data['nav']  = $this->form_model->get_data_query('SELECT * FROM s_nav WHERE 1 group by id_s_nav ' );
	    $data['role'] = $this->form_model->get_data_query('SELECT * FROM role,s_nav WHERE id_s_nav=id_nav_role AND id_user_role='.$id );
	    
	    
	    $this->load->view('header'); 
		$this->load->view('root/role', $data);
		$this->load->view('footer');
	}
	public function add_role($id,$role){
	    $data=array( 'id_user_role' => $id ,
		               'id_nav_role' => $role  
		           );
	
	    if($this->form_model->add_data('role', $data) ) {  
	        $this->role_user($id);
	    }else{
	        $this->role_user($id);
	    }
	}
	public function del_role($id,$role){
	    if($this->form_model->update_query('DELETE FROM `role` WHERE id_user_role='.$id.' AND id_nav_role='.$role) ) {  
	        $this->role_user($id);
	    }else{
	        $this->role_user($id);
	    }
	}
	public function edite_role($id){
	    
	}
	
// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---		
		
	public function list_menu(){
	    $data['data'] = $this->form_model->get_data_query('SELECT * FROM nav WHERE 1 ORDER BY id_nav'  );
	    $data['s_nav'] = $this->form_model->get_data_query('SELECT * FROM s_nav WHERE 1 ORDER BY id_nav_s_nav'  );
	    
	    
	    $this->load->view('header'); 
		$this->load->view('root/menu',$data);
		$this->load->view('footer');
	}
	public function Add_Menu(){
	    
		$this->form_validation->set_rules('text', 'text', 'trim|required');
		
		if ($this->form_validation->run() == false) { 
			$this->list_menu();
		} else { 
		    $type = $this->input->post('type');
		    
		    ($type == 0 ? $ref = '_nav' : $ref = '_s_nav' );
		    ($type == 0 ? $table = 'nav' : $table = 's_nav' );
		    
    	    $data['text'.$ref] = $this->input->post('text') ;
    		$data['href'.$ref] = $this->input->post('href');
    		$data['class'.$ref] = $this->input->post('class');
    		$data['icon'.$ref] = $this->input->post('icon');
    		// ($type == 1 ? $data['id_nav_s_nav'] = $this->input->post('type') : '' );
    	
    	    if($this->form_model->add_data($table , $data) ) {  
    	        $_SESSION['msg'] = 'Bien Ajouter';
    	    }else{
    	        $_SESSION['msg'] = 'Error de ajouter';
    	    }
    	    $this->list_menu();
		}
	}
	public function Add_S_Menu(){
		
		$this->form_validation->set_rules('nav', 'nav', 'trim|required');
		$this->form_validation->set_rules('s_nav', 's_nav', 'trim|required');
		
		if ($this->form_validation->run() == false) { 
			$this->list_menu();
		} else { 
		   $nav = $this->input->post('nav');
		   $s_nav = $this->input->post('s_nav');
    	    if($this->form_model->update_query('UPDATE `s_nav` SET id_nav_s_nav='. $nav .' WHERE id_s_nav='.$s_nav) ) {  
    	        $_SESSION['msg'] = 'Bien Ajouter Sous Menu';
    	    }else{
    	        $_SESSION['msg'] = 'Error de ajouter Sous Menu !!';
    	    }
    	    $this->list_menu();
		}
	}
	public function del_menu($id,$role){
	    if($this->form_model->update_query('DELETE FROM `role` WHERE id_user_role='.$id.' AND id_nav_role='.$role) ) {  
	        $this->role_user($id);
	    }else{
	        $this->role_user($id);
	    }
	}
	public function Del_S_Menu($id){
	    if($this->form_model->update_query("UPDATE `s_nav` SET id_nav_s_nav=null WHERE id_s_nav=".$id) ) {  
	         $_SESSION['msg'] = 'Bien Supprimer';
	    }else{
	         $_SESSION['msg'] = 'Erreur de Suppression !!';
	    }
	    $this->list_menu();
	}
	
// --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---	

	public function auth() { 
		$data = new stdClass();
		if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == TRUE )redirect(base_url('/home'));
		
		$_SESSION['msg'] ='';
		
		$this->form_validation->set_rules('role', 'Role', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required|alpha_numeric');
		
		if ($this->form_validation->run() == false) { 
			$this->load->view('head_log'); 
			$this->load->view('root/login'); 
			
		} else { 
		    
			$role = $this->input->post('role');
			$password = $this->input->post('password');
			
			if ($user_id = $this->user_model->user_login($role,$password)) {
				
				$user    = $this->user_model->get_user($user_id);
				
				$this->form_model->is_connecte((int)$user->id);
				
				$_SESSION['user_id']      = (int)$user->id;
				$_SESSION['role']         = (int)$user->role;
				$_SESSION['username']     = (string)$user->username;
				$_SESSION['logged_in']    = (bool)true;
				$_SESSION['is_confirmed'] = (bool)$user->is_confirmed;
				$_SESSION['is_admin']     = (bool)$user->is_admin;
				$_SESSION['clt'] = 1;
				 
				redirect(base_url('/home')); 
			} else {  
				 redirect('/'); 
			} 
		} 
	}
	
	public function de_auth() { 
			if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
			    if(	$_SESSION['username'] == 'Conducteur'){
			        $this->form_model->update_query("UPDATE `salarie` SET active_sal=0 WHERE id_sal=".$_SESSION['user_id'] );
			        
			        $this->form_model->is_deconnecte($_SESSION['user_id']);
        			foreach ($_SESSION as $key => $value) {
        				unset($_SESSION[$key]);
        			}
        			 redirect('/pdt');
    			 
			    }
			    $this->form_model->is_deconnecte($_SESSION['user_id']);
    			foreach ($_SESSION as $key => $value) {
    				unset($_SESSION[$key]);
    			}
    			 redirect('/');
    		} else {
    			redirect('/');
    		}
	}
	
	public function forgot_password(){
	    
	}
	
	public function reset($id){ 

		if ($id) {   
                            
            $this->form_model->update_data('users',array('password' => password_hash('123456', PASSWORD_BCRYPT)) , array('id' => $id));	
            
		} 
		redirect(base_url('index.php/root/list_user'));
	}

	public function profile() { 
	    
	    $this->load->helper('form');
		$this->load->library('form_validation');
		 
		$this->form_validation->set_rules('id', 'id', 'required');
		
		if ($this->form_validation->run() === false) {     
		    $data['msg'] = false;
		    $data['row'] = $this->form_model->get_row_query('SELECT * FROM users WHERE id='.$_SESSION['user_id'] );

			$this->load->view('header');
			$this->load->view('root/profile',$data);
			$this->load->view('footer');
		} else {
		    
    		  $id = $this->input->post('id');
              $data=array( 'email' => $this->input->post('email') ,
    		               'tel' => $this->input->post('tel')  ,
    		               'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT)
    		                            );
		
		    if($this->form_model->update_data('users',$data,'id',$id)) {  
		        $data['msg'] = 'Bien Modifier';
    	    }else{
    	        $data['msg'] = 'Error de modification';
    	    }
    	    
    	    $data['row'] = $this->form_model->get_row_query('SELECT * FROM users WHERE id='.$_SESSION['user_id'] );
			$this->load->view('header');
			$this->load->view('root/profile',$data);
			$this->load->view('footer');
		}
	}

	
}
