<?php

	function get_user(){
        $CI = get_instance();
        $CI->load->model('form_model');
        
        $data = $CI->form_model->get_row_query('SELECT * FROM `users` WHERE id='.$_SESSION['user_id']);
        
        return $data;
    }
    
    /**
    *   Get HTML navbar user role
    **/
    function nav(){
       $CI = get_instance();
        $CI->load->model('form_model');
        $data = $CI->form_model->get_data_query('SELECT * FROM `role`,`s_nav`,`nav` WHERE visible=1 AND id_nav=id_nav_s_nav AND id_s_nav=id_nav_role AND id_user_role='.$_SESSION['role'].' GROUP BY id_nav ORDER BY position');
        
        
        $html = '';
        if($data) foreach($data as $nav):
            $html.='      <li class="nav-item dropdown"> ';
            $html.='        <a href="'. base_url($nav->href_nav) .'" class="nav-link" data-toggle="dropdown"><i class="'.$nav->icon_nav.'"></i> '.$nav->text_nav.' </a> ';
            $html.='        <div class="dropdown-menu dropdown-menu-arrow"> ';
            
            $s_data = $CI->form_model->get_data_query('SELECT * FROM `role`,`s_nav` WHERE id_s_nav=id_nav_role AND id_user_role='.$_SESSION['role'].' AND id_nav_s_nav='.$nav->id_nav_s_nav.' GROUP BY id_s_nav');
            foreach($s_data as $s_nav):
                $html.='          <a href="'. base_url($s_nav->href_s_nav) .'" class="dropdown-item"> <i class="'.$s_nav->icon_s_nav.'"></i> '. $s_nav->text_s_nav .' </a> ';
            endforeach;
            $html.='        </div> ';
            $html.='      </li> ';
        endforeach; 
        
        return $html;
    }
    
    /**
    *   Get user info(id_user,id_nav)
    **/
    function get_role($id,$role){
        $CI = get_instance();
        $CI->load->model('form_model');
        
        $data = $CI->form_model->get_row_query('SELECT * FROM `role` WHERE id_nav_role='.$role.' AND id_user_role='.$id );
        if($data)
            return true;
        else
            return false;
    }

    /**
    *   Get Snav info(id_nav)
    **/
    function get_s_nav($id){
        $CI = get_instance();
        $CI->load->model('form_model');
        
        $data = $CI->form_model->get_data_query('SELECT * FROM `s_nav` WHERE id_nav_s_nav='.$id );
        if($data)
            return $data;
        else
            return false;
    }

    
	function date_str($date){
	        return date('Y-m-d', strtotime($date));
	    }






 




?>