<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
 
	public function __construct() {
		
		parent::__construct();
		$this->load->database();
		
	}
	 
	public function create_user($username, $email, $password) { 
		
		$data = array(
			'username'   => $username,
			'email'      => $email,
			'password'   => password_hash($password, PASSWORD_BCRYPT),
			'created_at' => date('Y-m-j H:i:s'),
		);
		
		return $this->db->insert('users', $data);
		
	}
	 
	public function user_login($role, $password) {
		
		$this->db->select('id,password');
		$this->db->from('users');
		$this->db->where('role', $role);
		$hash = $this->db->get()->row();
		
		if( password_verify($password, $hash->password))
	    	return $hash->id;
		else 
	    	return false;
		
	}
	 
	public function get_user($user_id) {
	    
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('id', $user_id);
		return $this->db->get()->row();
		
	}
	 
	
}
