<!doctype html>
<html lang="ar" dir="RTL">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge"> 
    <title> Users Roles </title>
     
    <script src="<?= base_url('assets/js/require.min.js') ?>"></script>
    <script>
      requirejs.config({
          baseUrl: '<?= base_url() ?>'
      });
    </script> 
    <link href="<?= base_url('/assets/css/dashboard.rtl.css') ?>" rel="stylesheet" />
    <script src="<?= base_url('assets/js/dashboard.js') ?>"></script>
    <link href="<?= base_url('assets/plugins/charts-c3/plugin.css') ?>" rel="stylesheet" />
    <script src="<?= base_url('assets/plugins/charts-c3/plugin.js') ?>"></script> 
    <script src="<?= base_url('assets/plugins/input-mask/plugin.js') ?>"></script>
    <script src="<?= base_url('assets/js/ajax_jquery.min.js') ?>"></script>
    <style> 
      .keyboardInputInitiator { 
      }
    </style>
     
    <!--script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script-->
  </head>
  <body class="">
      <div class="page">
        <div class="page-main">