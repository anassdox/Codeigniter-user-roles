﻿<?php if(!$_SESSION['logged_in']): redirect(base_url('root')); endif; ?>
<!doctype html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge"> 
    <title> Users Roles </title>
     
    <script src="<?= base_url('assets/js/require.min.js') ?>"></script>
    <script>
      requirejs.config({
          baseUrl: '<?= base_url() ?>'
      });
    </script> 
    <link href="<?= base_url('/assets/css/dashboard.rtl.css') ?>" rel="stylesheet" />
    <script src="<?= base_url('assets/js/dashboard.js') ?>"></script>
    <link href="<?= base_url('assets/plugins/charts-c3/plugin.css') ?>" rel="stylesheet" />
    <script src="<?= base_url('assets/plugins/charts-c3/plugin.js') ?>"></script> 
    <script src="<?= base_url('assets/plugins/input-mask/plugin.js') ?>"></script>
    <script src="<?= base_url('assets/js/ajax_jquery.min.js') ?>"></script>
    <style> 
      .keyboardInputInitiator { 
      }
    </style>
    
    <script> 
       $(document).ready(function() { 

          $('#clt').change( function(){  
            $.ajax({
               type:'POST',
               dataType: "json",
               url: "<?= base_url('index.php/home/select_clt') ?>/"+$('#clt').val(),
               data: {  },
               success: function(data){
                    console.log(data);   
               },error: function (data) {
                    console.log('An error occurred.');  
                },
             });
            return false; 
          });
      }); 
    </script>
    <!--script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script-->
  </head>
  <body class="" style="direction: rtl;">
      <div class="page">
        <div class="page-main">
            <div class="header py-4">
              <div class="container">
                <div class="d-flex">
                  <a class="header-brand" href="<?= base_url() ?>">
                    Users Roles
                  </a>
                  <div class="d-flex order-lg-2 ml-auto">
                    <div class="dropdown d-none d-md-flex">
                      <a class="nav-link icon" data-toggle="dropdown">
                        <i class="fe fe-bell"></i>
                        <span class="nav-unread"></span>
                      </a>
                      <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">

                        <a href="#" class="dropdown-item d-flex">
                          <span class="avatar mr-3 align-self-center"></span>
                          <div>
                            <strong> msg</strong> 
                            <div class="small text-muted">10 minutes ago</div>
                          </div>
                        </a>

                        <div class="dropdown-divider"></div>
                        <a href="#" class="dropdown-item text-center text-muted-dark">Mark all as read</a>
                      </div>
                    </div>

                    <!--div class="input-icon row col-xs-2 center-block">
                      <input type="date" value="<?= date("Y-m-d") ?>" name="created" id="created" class="form-control header-search">
                      <div class="input-icon-addon">
                        <i class="fe fe-search"></i>
                      </div>
                    </div-->

                    <div class="dropdown">
                      <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                        <span class="avatar" style="background-image: url()"></span>
                        <span class="ml-2 d-none d-lg-block">
                          <span class="text-default"> <?= get_user()->nom.' '.get_user()->prenom ?> </span>
                          <small class="text-muted d-block mt-1"> <?= get_user()->username ?> </small>
                        </span>
                      </a>
                      <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                        <a class="dropdown-item" href="<?= base_url('index.php/root/profile') ?>">
                          <i class="dropdown-icon fe fe-user"></i> Profile
                        </a>
                         
                        <a class="dropdown-item" href="#">
                          <span class="float-right"><span class="badge badge-primary">6</span></span>
                          <i class="dropdown-icon fe fe-mail"></i> Inbox
                        </a>
                         
                        <div class="dropdown-divider"></div>
                         
                        <a class="dropdown-item" href="<?= base_url('index.php/root/de_auth') ?>">
                          <i class="dropdown-icon fe fe-log-out"></i> Déconnecte
                        </a>
                      </div>
                    </div>

                  </div>
                  <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse" data-target="#headerMenuCollapse">
                    <span class="header-toggler-icon"></span>
                  </a>
                </div>
              </div>
            </div>
            <div class="header collapse d-lg-flex p-0" id="headerMenuCollapse">
              <div class="container">
                <div class="row align-items-center"> 
                  <div class="col-lg order-lg-first">
                    <ul class="nav nav-tabs border-0 flex-column flex-lg-row">
                      <li class="nav-item">
                        <a href="<?= base_url() ?>" class="nav-link active"><i class="fe fe-home"></i> Accueil </a>
                      </li>
                      <?= nav() ?>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

        <script>
            $("#searching").keyup(function () {
                //split the current value of searchInput
                var data = this.value.split(" ");
                //create a jquery object of the rows
                var jo = $("tbody").find("tr");
                if (this.value == "") {
                    jo.show();
                    return;
                }
                //hide all the rows
                jo.hide();
            
                //Recusively filter the jquery object to get results.
                jo.filter(function (i, v) {
                    var $t = $(this); 
                    for (var d = 0; d < data.length; ++d) {
                        if ($t.is(":contains('" + data[d] + "')")) {
                            return true;
                        }
                    }
                    return false;
                })
                //show the rows that match.
                .show();
            }).focus(function () {
                this.value = "";
                $(this).css({
                    "color": "black"
                });
                $(this).unbind('focus');
            }).css({
                "color": "#C0C0C0"
            });
        </script>