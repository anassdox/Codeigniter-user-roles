           
    <div class="page">
      <div class="page-single">
        <div class="container">
          <div class="row">
            <div class="col-md-12">                
                        
                        <h1><?php echo 'Gestion Utilisateur'; ?></h1>
                        <p><?php echo 'Role Utilisateur'; ?></p>
                        
                        <div id="infoMessage"><?php ?></div>
                        
                            <div class="card">
                              <div class="table-responsive">
                                <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
                                  <thead>
                                    <tr>
                                      <th class="text-center w-1"><i class="icon-people"></i></th>
                                      <th>Name</th>
                                      <th>Role</th>
                                      <th class="text-center"> <i class="icon-settings"></i> Reset Password</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    
                                    <?php if($data) foreach ($data as $user): ?>
                                    <tr>
                                      <td class="text-center">
                                        <div class="avatar d-block" style="background-image: url(demo/faces/female/26.jpg)">
                                          <span class="avatar-status bg-green"></span>
                                        </div>
                                      </td>
                                      <td>
                                        <div><?= htmlspecialchars($user->nom,ENT_QUOTES,'UTF-8');?> <?= htmlspecialchars($user->prenom,ENT_QUOTES,'UTF-8');?> </div>
                                        <div class="small text-muted">
                                          <?= 'Email';?>: <?= htmlspecialchars($user->email,ENT_QUOTES,'UTF-8');?>
                                        </div>
                                      </td>
                                      <td>
                                           <?= anchor("root/role_user/".$user->id, htmlspecialchars($user->username,ENT_QUOTES,'UTF-8'), 'class="btn btn-outline-primary btn-sm"') ;?>
                                      </td>
                                     
                                      <td class="text-center"> 
                                        <?= anchor("root/reset/".$user->id, 'Reset','class="btn btn-secondary btn-sm"') ;?>
                                      </td>
                                      
                                    </tr>  
                                    <?php endforeach;?>
                            
                                  </tbody>
                                </table>
                              </div>
                            </div>
                            
                            <?php echo anchor('root/register', 'Nouveaux Utilisateur' )?> 
    
             </div>
          </div>
       </div>
    </div>
  </div>
                        
                        
                
                        