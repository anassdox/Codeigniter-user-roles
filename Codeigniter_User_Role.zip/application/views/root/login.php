<?php defined('BASEPATH') OR exit('No direct script access allowed'); //device_info(); ?>

     <div class="page">
      <div class="page-single">
        <div class="container">
          <div class="row">
            <div class="col col-login mx-auto">
              <div class="card">
                  <div class="card-body p-6">
                      
                    <h1> Loging </h1>
                    
                    <?= form_open() ?>
                            <div class="form-group">
                                <label for="password"> <?php echo 'identity';?> </label> 
                                <select  class="form-control" id="role" name="role">
            					    <option value="2"> User 1</option>
            					    <option value="3">User 2</option> 
                          			<option value="1"> Dev </option>
              					</select>
                            </div>
                            <div class="form-group">
                                <label for="username-email"><?php echo 'password';?></label>
                                <input id="password" name="password" value="" type="password" class="form-control" />
                            </div>
                            <div class="form-group text-center">
                                <?php echo form_submit('submit', 'Connecté', 'class="btn btn-primary btn-block"');?>
                            </div>
                        </form>
                        
                   
                    <div class="text-center text-muted">
                        <!--a href="forgot_password"><?php echo  'login_forgot_password' ;?></a-->
                    </div>
                    
                  </div>
               </div>
            </div>
           </div>
         </div>
      </div>
    </div>
          
          
          