           
    <div class="page">
      <div class="page-single">
        <div class="container">
          <div class="row">
              
            <div class="col-md-4">  
            
                <h1>Ajouter Sous-Menu</h1>
                <div class="card">
                  <div class="card-body">
                    <p> <?= $_SESSION['msg'] ?> </p>    
                  
                    <?= form_open(base_url('index.php/root/Add_S_Menu')) ?>    
                    <div class="form-group">
                      <select name="nav" class="form-control custom-select">
                          
                        <?php if($data) foreach ($data as $row): ?> 
                        <option value="<?= $row->id_nav ?>"><?= $row->text_nav ?></option>
                        <?php endforeach;?>
                        
                      </select>
                    </div>
                    <div class="form-group">
                      <select name="s_nav" class="form-control custom-select">
                          
                        <?php if($s_nav) foreach ($s_nav as $row): ?> 
                        <option value="<?= $row->id_s_nav ?>"><?= $row->text_s_nav ?></option>
                        <?php endforeach;?>
                        
                      </select>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block"> Ajouter </button>
                    </div>
                  </form>  
                  
                  </div>
                </div>
                <hr>
                <h1>Ajouter Menu</h1>
                <div class="card">
                  <div class="card-body">
                  <p> <?= $_SESSION['msg'] ?> </p>    
                  
                  <?= form_open(base_url('index.php/root/Add_Menu')) ?>     
                    <div class="form-group">
                        <div class="input-group">
                          <span class="input-group-prepend" id="basic-addon1">
                            <span class="input-group-text">Text</span>
                          </span>
                          <input type="text" class="form-control" name="text" placeholder="Text" aria-label="Text" aria-describedby="basic-addon1">
                        </div>
                    </div>
                       
                    <div class="form-group">
                        <div class="input-group">
                          <span class="input-group-prepend" id="basic-addon1">
                            <span class="input-group-text">Href</span>
                          </span>
                          <input type="text" class="form-control" name="href" placeholder="Href" aria-label="Href" aria-describedby="basic-addon1">
                        </div>
                    </div>
                       
                    <div class="form-group">
                        <div class="input-group">
                          <span class="input-group-prepend" id="basic-addon1">
                            <span class="input-group-text">Class</span>
                          </span>
                          <input type="text" class="form-control" name="class" placeholder="class" aria-label="class" aria-describedby="basic-addon1">
                        </div>
                    </div>
                       
                    <div class="form-group">
                        <div class="input-group">
                          <span class="input-group-prepend" id="basic-addon1">
                            <span class="input-group-text">Icon</span>
                          </span>
                          <input type="text" class="form-control" name="icon" placeholder="icon" aria-label="icon" aria-describedby="basic-addon1">
                        </div>
                    </div>
                    
                    
                    <div class="selectgroup selectgroup-pills">
                      <label class="selectgroup-item">
                        <input type="radio" name="type" value="0" class="selectgroup-input" checked="">
                        <span class="selectgroup-button selectgroup-button-icon"> Menu </span>
                      </label>
                      <label class="selectgroup-item">
                        <input type="radio" name="type" value="1" class="selectgroup-input">
                        <span class="selectgroup-button selectgroup-button-icon"> Sous-Menu</span>
                      </label>
                    </div>
                        
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block"> Ajouter </button>
                    </div>
                  </form>
                  
                  </div>
                </div>
                
            </div>
            
            <div class="col-md-8">   
              <h1>List Menu</h1>
              <div class="card">      
                  <?php if($data) foreach ($data as $row):  $s_nav = get_s_nav($row->id_nav); ?> 
                  <ul class="list-group card-list-group">
                    <li class="list-group-item py-5">
                      <div class="media">
                        <div class="media-object avatar avatar-md mr-4" style="background-image: url()"> <?= $row->id_nav ?> </div>
                        <div class="media-body">
                          <div class="media-heading">
                            <h5> <?= htmlspecialchars($row->text_nav,ENT_QUOTES,'UTF-8');?>  </h5>
                          </div>
                          <div>
                            <span class="badge badge-info"> Href : <?= htmlspecialchars($row->href_nav,ENT_QUOTES,'UTF-8');?> </span> | 
                            <span class="badge badge-warning"> Class: <?= htmlspecialchars($row->class_nav,ENT_QUOTES,'UTF-8');?> </span> | 
                            <span class="badge badge-success"> Icon : <?= htmlspecialchars($row->icon_nav,ENT_QUOTES,'UTF-8');?> </span>
                          </div>
                          <ul class="media-list">
                              
                            <?php if($s_nav) foreach ($s_nav as $ligne): ?>
                            <li class="media mt-4">
                              <div class="media-object avatar mr-4" style="background-image: url()"> <?= $ligne->id_s_nav ?> </div>
                              <div class="media-body">
                                <strong> <?= $ligne->text_s_nav ?> </strong>
                                <?= anchor("root/Del_S_Menu/".$ligne->id_s_nav, 'Del', 'class="btn btn-danger btn-sm float-right"') ?> 
                                <div>
                                    <span class="badge badge-info"> Href : <?= htmlspecialchars($ligne->href_s_nav,ENT_QUOTES,'UTF-8');?> </span> | 
                                    <span class="badge badge-warning"> Class: <?= htmlspecialchars($ligne->class_s_nav,ENT_QUOTES,'UTF-8');?> </span> | 
                                    <span class="badge badge-success"> Icon : <?= htmlspecialchars($ligne->icon_s_nav,ENT_QUOTES,'UTF-8');?> </span>
                                </div>
                              </div>
                            </li>
                            <?php endforeach;?>
                            
                          </ul>
                        </div>
                      </div>
                    </li>
                    
                  </ul>
                  <hr>
                  <?php endforeach;?>
                            
               </div>
            </div>    
    
         </div>
      </div>
   </div>
</div>
                        
                        
                
                        