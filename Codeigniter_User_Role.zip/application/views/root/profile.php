        
        
        <div class="my-3 my-md-5">
          <div class="container">
              
            <!--    Total     -->  
            <div class="page-header">
              <h1 class="page-title">
                Mon Profile
              </h1>
            </div>
            
            
            <input type="hidden" value="<?= $row->id ?>" name="id">
            <div class="col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Mes Information</h3>
                  </div>
                  <div class="card-body">
                    <?= form_open() ?>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar avatar-xl" style="background-image: url(demo/faces/female/9.jpg)"></span>
                        </div>
                        <div class="col">
                            <h3 class="mb-3"><?= $row->username ?></h3>
                            <p class="mb-4">
                              <?= $row->nom .' '.$row->prenom ?>
                            </p>
                            <p>
                                <?= $row->email ?>
                            </p>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" id="password" class="form-control" value="">
                      </div>
                      <div class="form-group">
                        <label class="form-label">Re-Password</label>
                        <input type="password" id="password1" class="form-control" value="">
                        <span id="6char" class=" " style="color:#FF0004;"></span> 6 Characters<br>
                        <span id="pwmatch" class=" " style="color:#FF0004;"></span> Passwords Match
                      </div>
                      <div class="form-footer">
                        <button id="valide" class="btn btn-primary btn-block" disabled>Sauvgarder</button>
                      </div>
                      <p> <?= $_SESSION['msg'] ?> </p>
                    </form>
                  </div>
                </div>
              </div>
              
          </div>
        </div>
        
        <script>
            $("input[type=password]").keyup(function(){
                var ucase = new RegExp("[A-Z]+");
            	var lcase = new RegExp("[a-z]+");
            	var num = new RegExp("[0-9]+");
            	
            	if($("#password").val().length >= 6){
            		$("#6char").removeClass("fe fe-alert-circle");
            		$("#6char").addClass("fe fe-check-circle");
            		$("#6char").css("color","#00A41E");
            	}else{
            		$("#6char").removeClass("fe fe-check-circle");
            		$("#6char").addClass("fe fe-alert-circle");
            		$("#6char").css("color","#FF0004");
            		$('#valide').prop('disabled', true);
            	}
            	
            	if($("#password").val() == $("#password1").val()){
            		$("#pwmatch").removeClass("fe fe-alert-circle");
            		$("#pwmatch").addClass("fe fe-check-circle");
            		$("#pwmatch").css("color","#00A41E");
            		
            		$('#valide').prop('disabled', false);
            	}else{
            		$("#pwmatch").removeClass("fe fe-check-circle");
            		$("#pwmatch").addClass("fe fe-alert-circle");
            		$("#pwmatch").css("color","#FF0004");
            		$('#valide').prop('disabled', true);
            	}
            });
        </script>

                    
                    
                    