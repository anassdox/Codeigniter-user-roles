           
    <div class="page">
      <div class="page-single">
        <div class="container">
          <div class="row">
            <div class="col-md-12">                
                        
                        <h1><?php echo ('Utilisateur');?></h1>
                        <p><?php echo ('Role Utilisateur');?></p>
                        
                        <div id="infoMessage"><?php ?></div>
                        
                            <div class="card">
                              <div class="table-responsive">
                                <table class="table table-hover table-outline table-vcenter text-nowrap card-table">
                                  <thead>
                                    <tr>
                                      <th>Role</th>
                                      <th>Href</th>
                                      <th class="text-center"> <i class="icon-settings"></i> Active</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    
                                    <?php if($nav) foreach ($nav as $row): ?>
                                    <tr>
                                      <td>
                                        <div><?= htmlspecialchars($row->text_s_nav,ENT_QUOTES,'UTF-8');?> </div>
                                      </td>
                                      <td>
                                           <div><?= htmlspecialchars($row->href_s_nav,ENT_QUOTES,'UTF-8');?> </div>
                                      </td>
                                     
                                      <td class="text-center">
                                        <?= (!get_role($user->role,$row->id_s_nav)) ? anchor("root/add_role/".$user->role."/".$row->id_s_nav, 'active', 'class="btn btn-primary btn-sm"') : anchor("root/del_role/".$user->role."/".$row->id_s_nav, 'Inactive', 'class="btn btn-warning btn-sm"');?> 
                                      </td>
                                      
                                    </tr>   
                                    <?php endforeach;?>
                            
                                  </tbody>
                                </table>
                              </div>
                            </div>
                            
                            <?php echo anchor('root/register', ('index_create_user_link'))?>
    
             </div>
          </div>
       </div>
    </div>
  </div>
                        
                        
                
                        