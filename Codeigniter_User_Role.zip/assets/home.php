          <div class="my-3 my-md-5">
            <div class="container">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title"> قائمة السائقين </h3>
                  </div>
                  <div class="table-responsive">
                    <table class="table table-hover card-table table-vcenter text-nowrap">
                      <thead>
                        <tr>
                          <th class="w-1">ID</th>
                          <th>الاسم الكامل </th>
                          <th> رقم البطاقة</th>
                          <th>الهاتف</th>
                          <th>التاريخ</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($data) foreach($data as $row):  ?>
                        <tr>
                          <td><span class="text-muted"><?= $row->id_c; ?></span></td>
                          <td><a href="" class="text-inherit"><?= $row->nom.' '.$row->prenom; ?></a></td>
                          <td> <?= $row->cin; ?>  </td>
                          <td>  <?= $row->tel; ?>  </td>
                          <td> <?= date_str($row->date); ?> </td>

                          <?php  if($_SESSION['role'] == 2 ):   ?>
                          <td class="text-right"> 
                            <a href="<?= base_url('index.php/chauffeur/list_pay/'.$row->id_c) ?>" class="btn btn-info btn-md"><i class="fe fe-grid" ></i>  المزيد</a> 
                          </td>
                          <?php else: ?> 
                          <td class="text-right">
                            <input type="hidden" id="id_chauffeur" value="<?= $row->id_c; ?>">
                            <a href="<?= base_url('index.php/chauffeur/list_pay/'.$row->id_c) ?>" class="btn btn-info btn-sm"><i class="fe fe-grid" ></i> المزيد</a>
                            <button type="button" id="del" class="btn btn-danger btn-sm"><i class="fe fe-trash-2" ></i> مسح </button>
                          </td>
                          <?php endif; ?>

                        </tr>
                      <?php endforeach; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <script type="text/javascript"> 
            $(document).ready(function() {

                $('button#del').click( function(){ 
                  var row = $(this).parent(); 

                  var checkstr =  confirm('Vous Voulez Vraiment supprimer ce chauffeur !!');
                  if(checkstr == true){

                    var id = row.find('input#id_chauffeur').val();
                    $.ajax({
                       type:'POST',
                       dataType: "html",
                       url: "<?= base_url('index.php/chauffeur/del/') ?>/"+id,
                       data: {  },
                       success: function(data){
                            console.log(data);  
                            location.reload();
                       },error: function (data) {
                            console.log('An error occurred.'); 
                        },
                     });
                    return false; 
                  }
                });
            }); 
          </script>