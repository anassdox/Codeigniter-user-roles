-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mer. 18 déc. 2019 à 13:01
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `codeigniter`
--

-- --------------------------------------------------------

--
-- Structure de la table `bon`
--

CREATE TABLE `bon` (
  `id_b` int(11) NOT NULL,
  `num` varchar(255) NOT NULL,
  `littre` double NOT NULL,
  `ttc` double NOT NULL,
  `px_u` double NOT NULL,
  `date` datetime NOT NULL,
  `date_valide` datetime DEFAULT NULL,
  `valide` int(11) NOT NULL DEFAULT '0',
  `id_v` int(11) NOT NULL,
  `visible` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `bon`
--

INSERT INTO `bon` (`id_b`, `num`, `littre`, `ttc`, `px_u`, `date`, `date_valide`, `valide`, `id_v`, `visible`) VALUES
(1, '4015', 1007, 8186, 8, '2019-12-03 00:00:00', '2019-12-03 00:00:00', 1, 2, 0),
(2, '4032', 0, 0, 0, '2019-12-01 00:00:00', NULL, 0, 4, 0),
(3, '4032', 0, 0, 0, '2019-12-03 00:00:00', NULL, 0, 4, 0),
(4, '4032', 1211, 9846, 8, '2019-12-03 00:00:00', '2019-12-03 00:00:00', 1, 4, 0),
(5, '4339', 0, 0, 0, '2019-11-29 00:00:00', NULL, 0, 4, 0),
(7, '2', 284, 2416, 8, '2019-12-04 00:00:00', '2019-12-01 00:00:00', 1, 6, 0),
(14, '4319', 284, 2416, 8, '2019-12-09 00:00:00', '2019-12-08 00:00:00', 1, 9, 1),
(15, '4319', 314, 2672, 8, '2019-12-09 00:00:00', '2019-12-09 00:00:00', 1, 10, 1),
(16, '4319', 1007, 8186, 8, '2019-12-02 00:00:00', '2019-12-09 00:00:00', 1, 11, 1),
(17, '0', 300, 2553, 8, '2019-12-09 00:00:00', '2019-12-09 00:00:00', 1, 12, 1),
(18, '4341', 281, 2391, 8, '2019-12-09 00:00:00', '2019-12-09 00:00:00', 1, 13, 1),
(19, '4341', 918, 7812, 8, '2019-12-03 00:00:00', '2019-12-09 00:00:00', 1, 15, 1),
(20, '4343', 327, 2782, 8, '2019-12-06 00:00:00', '2019-12-09 00:00:00', 1, 16, 1),
(21, '4341', 200, 1702, 8, '2019-12-03 00:00:00', '2019-12-09 00:00:00', 1, 17, 1),
(22, '4339', 312, 2655, 8, '2019-12-05 00:00:00', '2019-12-09 00:00:00', 1, 18, 1),
(23, '4345', 311, 2646, 8, '2019-12-09 00:00:00', '2019-12-09 00:00:00', 1, 20, 1),
(24, '4345', 300, 2553, 8, '2019-12-09 00:00:00', '2019-12-09 00:00:00', 1, 21, 1),
(25, '4032', 1211, 9846, 8, '2019-12-09 00:00:00', '2019-12-09 00:00:00', 1, 22, 1),
(26, '4027', 911, 7406, 8, '2019-12-01 00:00:00', '2019-12-09 00:00:00', 1, 23, 1),
(27, '00', 1000, 8130, 8, '2019-12-02 00:00:00', '2019-12-09 00:00:00', 1, 24, 1),
(28, '00', 290, 2357, 8, '2019-12-05 00:00:00', '2019-12-09 00:00:00', 1, 25, 1),
(29, '4036', 768, 6244, 8, '2019-12-05 00:00:00', '2019-12-09 00:00:00', 1, 26, 1),
(30, '00', 2146, 17446, 8.31, '2019-12-11 00:00:00', '2019-12-10 00:00:00', 1, 27, 1),
(31, '00', 1937, 15747, 8, '2019-12-01 00:00:00', '2019-12-10 00:00:00', 1, 28, 1),
(33, '00', 1950, 15853, 8, '2019-12-01 00:00:00', '2019-12-10 00:00:00', 1, 31, 1),
(34, '00', 528, 4374, 8.35, '2019-12-07 00:00:00', '2019-12-10 00:00:00', 1, 32, 1),
(35, '00', 2158, 17544, 8, '2019-12-07 00:00:00', '2019-12-07 00:00:00', 1, 33, 1),
(36, '2070', 1806, 14682, 8, '2019-11-02 00:00:00', '2019-12-04 00:00:00', 1, 34, 1);

-- --------------------------------------------------------

--
-- Structure de la table `chauffeur`
--

CREATE TABLE `chauffeur` (
  `id_c` int(11) NOT NULL,
  `nom` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `prenom` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `cin` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `tel` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `visible` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `chauffeur`
--

INSERT INTO `chauffeur` (`id_c`, `nom`, `prenom`, `cin`, `tel`, `date`, `visible`) VALUES
(6, 'bouchaib', 'sabbir', 'WA225172', '0668963923', '2019-10-27 00:00:00', 1),
(5, 'bouchaib', 'sabbir', 'wa225172', '0668963923', '2019-12-03 00:00:00', 0),
(3, 'Hasaan', 'Braik', 'M250386', '0662089156', '2019-11-07 00:00:00', 1),
(4, 'ابراهيم', 'غفاري', '', '0662159714', '2019-12-03 00:00:00', 0),
(7, 'hasan', 'bouid', '', '0672240032', '2017-09-07 00:00:00', 1),
(8, 'hassan', 'raichi', 'm493756', '0662652670', '2019-12-03 00:00:00', 1),
(9, 'abd wahad', 'ben tisse', '', '0642175150', '2019-06-18 00:00:00', 1),
(10, 'ali', 'barakkat', '', '0658303017', '2019-04-14 00:00:00', 1),
(11, 'mohamd', 'azzam', '', '0661705516', '2018-07-05 00:00:00', 1),
(12, 'omar', 'aachari', '', '0642399422', '2019-12-03 00:00:00', 1),
(13, 'brahim', 'rhofari', 'bj126922', '0662159714', '2016-02-20 00:00:00', 1),
(14, 'salah', 'zbiri', '', '0707184028', '2019-11-01 00:00:00', 0),
(15, 'salah', 'zbiri', '', '0707184028', '2019-11-01 00:00:00', 0),
(16, 'salah', 'zbiri', '', '0707184028', '2019-11-01 00:00:00', 0),
(17, 'Salah', 'Zabiri', '', '0707184028', '2019-11-01 00:00:00', 1),
(18, '00', '0', '', '', '2019-12-09 00:00:00', 1);

-- --------------------------------------------------------

--
-- Structure de la table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('41e23d7fd73168af0a97a53cbd7a2afc62fa5654', '127.0.0.1', 1576668011, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363636383030393b),
('eab5d1ece871df312fc53ee1d30faea2462b87b7', '127.0.0.1', 1576530969, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363533303936343b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2231223b),
('66ec7e560e8b743530dc3ef2f5df0362fce53a77', '127.0.0.1', 1576523838, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532333534363b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2233223b),
('c98943f5ab2d986b834019acbed3421ff9c01803', '127.0.0.1', 1576524111, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532343033383b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2233223b),
('2832f4d933da11a75443876b3ac74cd416d29e68', '127.0.0.1', 1576524656, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532343635313b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2233223b),
('ccffb91d5642dfe7019940112fbc3f9ac0835f0e', '127.0.0.1', 1576525264, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532343938393b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2233223b),
('f838f885c84001928d14d0943d281a0d54398069', '127.0.0.1', 1576525626, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532353332373b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2233223b),
('9771af2a10adf83d897dcb9c34d221f0d9c65b8f', '127.0.0.1', 1576525927, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532353632393b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2233223b),
('e9a518f89e32325be35f2f665d6c0f4fb3c51576', '127.0.0.1', 1576526162, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532353933313b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2233223b),
('ab9c29023580e6ac5e5a2eaf3c36641b896777bd', '127.0.0.1', 1576526802, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532363530323b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2233223b),
('9319574688ace265536637ccf613698a39d7d0d3', '127.0.0.1', 1576527061, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532363830333b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2233223b),
('44e782cc530ebfb97e1079ca378c1b4b529bbef0', '127.0.0.1', 1576527224, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532373131363b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2233223b),
('271d3097f2c06b98ba1013bc22e44b774cf356d9', '127.0.0.1', 1576527845, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532373534353b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2233223b),
('14b3a85607ae3c5f4540983c03dd0b42c15670dd', '127.0.0.1', 1576528147, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532373835323b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2233223b),
('1d10e456804faf52a83a2d358aea2db28f1eb8f0', '127.0.0.1', 1576528398, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532383135353b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2231223b),
('23de45fd4ddc908953fa1cd0f2359a049c5ec7b0', '127.0.0.1', 1576528754, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532383435383b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2231223b),
('7f5f3a3003d3d6f50a35dbacc9410d4893d4008c', '127.0.0.1', 1576528845, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532383737393b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2231223b),
('bef56ab17de4313d8c02ffefdb6c3d96fe378316', '127.0.0.1', 1576529339, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532393039383b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2231223b),
('36aa6722dc11fe36e959723160a9491643df05af', '127.0.0.1', 1576529648, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363532393430393b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2231223b),
('bda642b419bb234a3d24d8bfcee57e4f5100dcc9', '127.0.0.1', 1576530340, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363533303034333b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2231223b),
('b2b6b6b46356a6564701d885ebd50b6c3929244b', '127.0.0.1', 1576530627, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363533303334383b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2231223b),
('b1dc9d4854f6a670aa3a4e0fdad2e585261ef0f6', '127.0.0.1', 1576530948, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363533303636313b6d73677c733a303a22223b757365725f69647c693a333b726f6c657c693a333b757365726e616d657c733a343a2275736572223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a303b636c747c733a313a2231223b),
('f4b610a9cde9f27e789c990158a83aa15539a450', '127.0.0.1', 1576670459, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363637303136323b6d73677c733a303a22223b757365725f69647c693a313b726f6c657c693a313b757365726e616d657c733a393a225375702061646d696e223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a313b636c747c693a313b),
('d5b85195ed53bac5e94be967d35c95cf930f9c8f', '127.0.0.1', 1576670470, 0x5f5f63695f6c6173745f726567656e65726174657c693a313537363637303436373b6d73677c733a303a22223b757365725f69647c693a313b726f6c657c693a313b757365726e616d657c733a393a225375702061646d696e223b6c6f676765645f696e7c623a313b69735f636f6e6669726d65647c623a313b69735f61646d696e7c623a313b636c747c693a313b);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id_clt` int(11) NOT NULL,
  `nom` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `tel` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP,
  `visible` int(11) DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id_clt`, `nom`, `tel`, `date`, `visible`) VALUES
(1, 'Jaafar Bekouchi', '06123456789', '2019-11-26 12:33:23', 1),
(2, 'Guergarat', '06', '2019-12-02 16:58:45', 1),
(3, 'dahbi', '0661079611', '2019-12-03 05:17:54', 1);

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

CREATE TABLE `facture` (
  `id_f` int(11) NOT NULL,
  `clt` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `total1` double DEFAULT NULL,
  `total2` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `desc` text CHARACTER SET utf8,
  `visible` int(11) NOT NULL DEFAULT '1',
  `date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `facture`
--

INSERT INTO `facture` (`id_f`, `clt`, `total1`, `total2`, `desc`, `visible`, `date`) VALUES
(1, 'cliente de ste agroalimentaire', 18488, 'cente-mile', 'transports des produite agroalimentaire de casa anfa', 0, '2019-12-12 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `info`
--

CREATE TABLE `info` (
  `id_i` int(11) NOT NULL,
  `max` double DEFAULT NULL,
  `ste` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `adress` text,
  `logo` varchar(255) DEFAULT NULL,
  `IR` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `linefacture`
--

CREATE TABLE `linefacture` (
  `id_lf` int(11) NOT NULL,
  `mat_motor` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `mat_frigo` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `prix` double DEFAULT NULL,
  `prix2` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `fct` int(11) NOT NULL,
  `visible` int(11) DEFAULT '1',
  `date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `linefacture`
--

INSERT INTO `linefacture` (`id_lf`, `mat_motor`, `mat_frigo`, `prix`, `prix2`, `fct`, `visible`, `date`) VALUES
(1, '46224F242', '216524F343', 9244, NULL, 1, 1, '2019-12-12 00:00:00'),
(2, '46224F242', '216524F343', 9244, NULL, 1, 1, '2019-11-12 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `nav`
--

CREATE TABLE `nav` (
  `id_nav` int(11) NOT NULL,
  `text_nav` text CHARACTER SET utf8 NOT NULL,
  `href_nav` text CHARACTER SET utf8 NOT NULL,
  `class_nav` text CHARACTER SET utf8 NOT NULL,
  `icon_nav` text CHARACTER SET utf8 NOT NULL,
  `position` int(11) NOT NULL DEFAULT '1',
  `visible` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `nav`
--

INSERT INTO `nav` (`id_nav`, `text_nav`, `href_nav`, `class_nav`, `icon_nav`, `position`, `visible`) VALUES
(1, 'Exemple', '#', 'nav-item dropdown', 'fe fe-calendar', 1, 1),
(8, 'Administrateur', '#', 'nav-item dropdown', 'fe fe-shield', 7, 1);

-- --------------------------------------------------------

--
-- Structure de la table `partenaire`
--

CREATE TABLE `partenaire` (
  `id_p` int(11) NOT NULL,
  `nom` varchar(255) CHARACTER SET utf8 NOT NULL,
  `tel` varchar(255) CHARACTER SET utf8 NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `visible` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `payement`
--

CREATE TABLE `payement` (
  `id_p` int(11) NOT NULL,
  `somme` double NOT NULL,
  `libel` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `id_v` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `visible` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `payement`
--

INSERT INTO `payement` (`id_p`, `somme`, `libel`, `id_v`, `date`, `visible`) VALUES
(1, 9846, '', 4, '2019-12-03 06:31:07', 1),
(2, 9846, '', 4, '2019-12-03 06:31:32', 1),
(3, 9846, '', 2, '2019-12-03 06:51:35', 1),
(4, 7406, '', 5, '2019-12-04 04:48:15', 1);

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE `role` (
  `id_role` int(11) NOT NULL,
  `id_user_role` int(11) NOT NULL,
  `id_nav_role` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`id_role`, `id_user_role`, `id_nav_role`) VALUES
(1, 1, 1),
(2, 1, 1),
(3, 1, 2),
(4, 1, 1),
(5, 1, 2),
(6, 1, 3),
(7, 1, 2),
(8, 1, 3),
(9, 1, 4),
(10, 1, 3),
(11, 1, 4),
(12, 1, 5),
(13, 1, 4),
(14, 1, 5),
(15, 1, 5),
(16, 1, 6),
(17, 1, 6),
(18, 1, 6),
(19, 1, 7),
(20, 1, 7),
(21, 1, 7),
(22, 1, 8),
(23, 1, 8),
(24, 1, 8),
(25, 1, 9),
(26, 1, 9),
(27, 1, 9),
(28, 1, 13),
(29, 1, 13),
(30, 1, 13),
(31, 1, 12),
(32, 1, 12),
(33, 1, 12),
(34, 1, 11),
(35, 1, 11),
(36, 1, 11),
(37, 1, 10),
(38, 1, 10),
(39, 1, 10),
(40, 1, 10),
(41, 1, 10),
(42, 1, 10),
(43, 1, 10),
(44, 1, 10),
(45, 1, 10),
(46, 1, 10),
(47, 1, 10),
(48, 1, 10),
(49, 1, 10),
(50, 3, 1),
(51, 3, 1),
(52, 3, 2),
(53, 3, 2),
(54, 3, 4),
(55, 3, 4),
(56, 3, 5),
(57, 3, 5),
(58, 3, 6),
(59, 3, 6),
(60, 3, 6),
(61, 3, 8),
(62, 3, 6),
(63, 3, 8),
(64, 3, 8),
(65, 3, 8),
(66, 3, 13),
(67, 3, 13),
(68, 3, 13),
(69, 3, 12),
(70, 3, 13),
(71, 3, 12),
(72, 3, 12),
(73, 3, 12),
(74, 3, 11),
(75, 3, 11),
(76, 3, 11),
(77, 3, 11),
(78, 3, 9),
(79, 3, 9),
(80, 3, 9),
(81, 3, 9),
(82, 2, 2),
(83, 2, 2),
(84, 2, 2),
(85, 2, 2),
(86, 2, 5),
(87, 2, 5),
(88, 2, 5),
(89, 2, 5),
(90, 2, 6),
(91, 2, 6),
(92, 2, 6),
(93, 2, 6),
(94, 2, 9),
(95, 2, 9),
(96, 2, 9),
(97, 2, 9),
(98, 2, 10),
(99, 2, 10),
(100, 2, 10),
(101, 2, 10),
(102, 2, 11),
(103, 2, 11),
(104, 2, 11),
(105, 2, 11),
(106, 2, 13),
(107, 2, 13),
(108, 2, 13),
(109, 2, 13),
(110, 2, 13),
(111, 2, 13),
(112, 2, 13),
(113, 2, 13),
(114, 2, 13),
(115, 2, 13),
(116, 2, 13),
(117, 2, 13),
(118, 1, 15),
(119, 1, 15),
(120, 1, 15),
(121, 1, 14),
(122, 1, 15),
(123, 1, 14),
(124, 1, 14),
(125, 1, 14),
(126, 1, 14),
(127, 1, 14),
(128, 1, 14),
(129, 1, 14),
(130, 1, 16),
(131, 1, 16),
(132, 1, 16),
(133, 1, 16),
(134, 1, 16),
(135, 3, 10),
(136, 3, 10),
(137, 3, 10),
(138, 3, 10),
(139, 3, 17),
(140, 3, 17),
(141, 3, 17),
(142, 3, 17),
(143, 2, 17),
(144, 2, 17),
(145, 2, 17),
(146, 2, 17),
(147, 1, 17),
(148, 1, 17),
(149, 1, 17),
(150, 1, 17),
(151, 1, 18),
(152, 1, 18),
(153, 1, 18),
(154, 1, 18),
(155, 2, 18),
(156, 2, 18),
(157, 2, 18),
(158, 2, 18),
(159, 3, 18),
(160, 3, 18),
(161, 3, 18),
(162, 3, 18),
(163, 3, 18),
(164, 3, 18),
(165, 3, 18),
(166, 3, 18);

-- --------------------------------------------------------

--
-- Structure de la table `salaire`
--

CREATE TABLE `salaire` (
  `id_s` int(11) NOT NULL,
  `libel` varchar(255) NOT NULL,
  `somme` double NOT NULL,
  `id_c` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `visible` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `salaire`
--

INSERT INTO `salaire` (`id_s`, `libel`, `somme`, `id_c`, `date`, `visible`) VALUES
(1, '', 2000, 6, '2019-12-03 00:00:00', 1),
(2, '', 200, 6, '2019-12-03 00:00:00', 0),
(3, '', 0, 6, '2019-12-03 00:00:00', 0),
(4, '', 20000, 6, '2019-12-04 00:00:00', 1),
(5, '', 20000, 4, '2019-12-04 00:00:00', 1),
(6, 'salf', 3000, 8, '2019-12-04 00:00:00', 1),
(7, '', 1000, 10, '2019-12-04 00:00:00', 1),
(8, '', 3400, 10, '2019-12-04 00:00:00', 1),
(9, '', 750, 10, '2019-12-04 00:00:00', 1),
(10, '', 300, 10, '2019-12-04 00:00:00', 1),
(11, '', 1000, 6, '2019-12-04 00:00:00', 0),
(12, '', 1000, 10, '2019-12-04 00:00:00', 1),
(13, '', 1000, 10, '2019-12-04 00:00:00', 1),
(14, '', 600, 10, '2019-12-04 00:00:00', 1),
(15, '', 4500, 10, '2019-12-04 00:00:00', 1),
(16, '', 500, 10, '2019-12-04 00:00:00', 1),
(17, '', 300, 10, '2019-12-04 00:00:00', 1),
(18, '', 1200, 10, '2019-12-04 00:00:00', 1),
(19, '', 800, 10, '2019-12-04 00:00:00', 1),
(20, '', 1000, 10, '2019-12-04 00:00:00', 1),
(21, '', 2950, 10, '2019-12-04 00:00:00', 1),
(22, '', 2950, 10, '2019-12-04 00:00:00', 1),
(23, '', 500, 14, '2019-12-04 00:00:00', 1),
(24, '', 1100, 16, '2019-12-04 00:00:00', 1),
(25, '', 300, 15, '2019-12-04 00:00:00', 1),
(26, '', 300, 15, '2019-12-04 00:00:00', 1);

-- --------------------------------------------------------

--
-- Structure de la table `s_nav`
--

CREATE TABLE `s_nav` (
  `id_s_nav` int(11) NOT NULL,
  `text_s_nav` text CHARACTER SET utf8 NOT NULL,
  `href_s_nav` text CHARACTER SET utf8 NOT NULL,
  `class_s_nav` text CHARACTER SET utf8 NOT NULL,
  `icon_s_nav` text CHARACTER SET utf8 NOT NULL,
  `id_nav_s_nav` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `s_nav`
--

INSERT INTO `s_nav` (`id_s_nav`, `text_s_nav`, `href_s_nav`, `class_s_nav`, `icon_s_nav`, `id_nav_s_nav`) VALUES
(14, 'Menu', 'index.php/root/Add_Menu', 'dropdown-item', 'fe fe-grid', 8),
(15, 'Utilisateur', 'index.php/root/list_user', 'dropdown-item', 'fe fe-users', 8),
(16, 'Backup DB', 'index.php/root/backup', 'dropdown-item', 'fe fe-database', 8);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) DEFAULT NULL,
  `is_confirmed` int(11) DEFAULT NULL,
  `is_admin` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `nom`, `prenom`, `username`, `email`, `password`, `role`, `is_confirmed`, `is_admin`, `created_at`) VALUES
(1, 'Anass', 'Dev', 'Sup admin', 'anass.dox@gmail.com', '$2y$10$CVzX8c.pB8VxHWcu93UWw.Vjhpapf/HLCWVmiFbLD7SrPtCmSi/5G', 1, 1, 1, '2019-11-12 16:06:54'),
(3, 'User 1', '', 'Admin', 'admin@gmail.com', '$2y$10$94NGHi3q9hQt1cjTAAb5Pu6EOgJPRCTArWdwUHlnG6KIbgUbL6j4G', 3, 1, 0, '2019-11-12 16:06:54'),
(2, 'User 2', '', 'Utilisateur', 'user@gmail.com', '$2y$10$rjH1bdtS2DIyWQ6OyCvlju.wb8FqS6yeJGc2KZgJ1XQW8yAJ77Iam', 2, 0, 0, '2019-11-12 16:06:54');

-- --------------------------------------------------------

--
-- Structure de la table `voyage`
--

CREATE TABLE `voyage` (
  `id_v` int(11) NOT NULL,
  `voyage` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `trans` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `matricule` varchar(255) CHARACTER SET utf8 NOT NULL,
  `id_c` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `date_fin` datetime DEFAULT NULL,
  `descr` text CHARACTER SET utf8,
  `etat` int(11) NOT NULL DEFAULT '1',
  `id_clt` int(11) NOT NULL DEFAULT '1',
  `visible` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `voyage`
--

INSERT INTO `voyage` (`id_v`, `voyage`, `trans`, `matricule`, `id_c`, `date`, `date_fin`, `descr`, `etat`, `id_clt`, `visible`) VALUES
(12, '', '', '865a82', 10, '2019-12-01 00:00:00', NULL, '', 1, 1, 1),
(9, 'casa  nwakchout', 'khodar', '16040a42', 6, '2019-12-01 00:00:00', NULL, '', 1, 2, 1),
(10, '', '', '39160a13', 6, '2019-12-02 00:00:00', NULL, '', 1, 2, 1),
(11, '', '', '865a82', 10, '2019-12-06 00:00:00', NULL, '', 1, 2, 1),
(13, '', '', '50606a59', 8, '2019-12-03 00:00:00', NULL, '', 1, 2, 1),
(14, '', '', '24365a13', 6, '2019-12-03 00:00:00', NULL, '', 1, 2, 1),
(15, '', '', '24365a13', 6, '2019-12-03 00:00:00', NULL, '', 1, 2, 1),
(16, '', '', '57131h6', 13, '2019-12-05 00:00:00', NULL, '', 1, 2, 1),
(17, '', '', '45337a7', 18, '2019-12-03 00:00:00', NULL, '', 1, 2, 1),
(18, '', '', '41630a13', 3, '2019-11-29 00:00:00', NULL, '', 1, 2, 1),
(19, '', '', '3530a82', 6, '2019-12-06 00:00:00', NULL, '', 1, 2, 1),
(20, '', '', '57136h6', 7, '2019-12-06 00:00:00', NULL, '', 1, 2, 1),
(21, '', '', '865a82', 10, '2019-12-06 00:00:00', NULL, '', 1, 2, 1),
(22, '', '', '41630a13', 3, '2019-11-29 00:00:00', NULL, '', 1, 1, 1),
(23, '', '', '57136h6', 7, '2019-12-20 00:00:00', NULL, '', 1, 1, 1),
(24, '', '', '50606a59', 8, '2019-12-04 00:00:00', NULL, '', 1, 1, 1),
(25, '', '', '16040a42', 6, '2019-12-05 00:00:00', NULL, '', 1, 1, 1),
(26, '', '', '57131h6', 6, '2019-12-05 00:00:00', NULL, '', 1, 1, 1),
(27, '', '', '39160a13', 18, '2019-11-29 00:00:00', NULL, '', 1, 3, 1),
(28, '', '', '35401a10', 18, '2019-12-01 00:00:00', NULL, '', 1, 3, 1),
(29, '', '', '39160a13', 6, '2019-12-01 00:00:00', NULL, '', 1, 3, 1),
(30, '', '', '6394a60', 3, '2019-12-10 00:00:00', NULL, '', 1, 3, 1),
(31, '', '', '6394a60', 3, '2019-12-08 00:00:00', NULL, '', 1, 3, 1),
(32, '', '', '35401a10', 18, '2019-12-06 00:00:00', NULL, '', 1, 3, 1),
(33, '', '', '3530a82', 6, '2019-12-07 00:00:00', NULL, '', 1, 3, 1),
(34, '', '', '5034b40', 6, '2019-11-02 00:00:00', NULL, '', 1, 3, 1);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `bon`
--
ALTER TABLE `bon`
  ADD PRIMARY KEY (`id_b`);

--
-- Index pour la table `chauffeur`
--
ALTER TABLE `chauffeur`
  ADD PRIMARY KEY (`id_c`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id_clt`);

--
-- Index pour la table `facture`
--
ALTER TABLE `facture`
  ADD PRIMARY KEY (`id_f`);

--
-- Index pour la table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id_i`);

--
-- Index pour la table `linefacture`
--
ALTER TABLE `linefacture`
  ADD PRIMARY KEY (`id_lf`);

--
-- Index pour la table `nav`
--
ALTER TABLE `nav`
  ADD PRIMARY KEY (`id_nav`);

--
-- Index pour la table `partenaire`
--
ALTER TABLE `partenaire`
  ADD PRIMARY KEY (`id_p`);

--
-- Index pour la table `payement`
--
ALTER TABLE `payement`
  ADD PRIMARY KEY (`id_p`);

--
-- Index pour la table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id_role`);

--
-- Index pour la table `salaire`
--
ALTER TABLE `salaire`
  ADD PRIMARY KEY (`id_s`);

--
-- Index pour la table `s_nav`
--
ALTER TABLE `s_nav`
  ADD PRIMARY KEY (`id_s_nav`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `voyage`
--
ALTER TABLE `voyage`
  ADD PRIMARY KEY (`id_v`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `bon`
--
ALTER TABLE `bon`
  MODIFY `id_b` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT pour la table `chauffeur`
--
ALTER TABLE `chauffeur`
  MODIFY `id_c` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `id_clt` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `facture`
--
ALTER TABLE `facture`
  MODIFY `id_f` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `info`
--
ALTER TABLE `info`
  MODIFY `id_i` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `linefacture`
--
ALTER TABLE `linefacture`
  MODIFY `id_lf` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `nav`
--
ALTER TABLE `nav`
  MODIFY `id_nav` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT pour la table `partenaire`
--
ALTER TABLE `partenaire`
  MODIFY `id_p` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `payement`
--
ALTER TABLE `payement`
  MODIFY `id_p` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `role`
--
ALTER TABLE `role`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;
--
-- AUTO_INCREMENT pour la table `salaire`
--
ALTER TABLE `salaire`
  MODIFY `id_s` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT pour la table `s_nav`
--
ALTER TABLE `s_nav`
  MODIFY `id_s_nav` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `voyage`
--
ALTER TABLE `voyage`
  MODIFY `id_v` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
